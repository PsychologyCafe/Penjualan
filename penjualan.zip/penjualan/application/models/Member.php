<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class member extends CI_Controller {
 public function __construct(){
 parent::__construct();
 $this->load->model(array('m_member','m_user'));
 date_default_timezone_set('Asia/Jakarta');
 }

 public function dataMember()
 {
 if (!$this->session->userdata('level')=='Admin') {
 redirect('login');
 }else{
 $data['admin'] = $this->m_user->selectAdmin()->row();
 $data['member'] = $this->m_member->getMember()->result();

 $this->load->view('admin/header',$data);
 $this->load->view('admin/dataMember');
 $this->load->view('admin/footer');
 }
 }
}

public function tambah($data){
    $this->db->insert_batch('member', $data);
    }
    
